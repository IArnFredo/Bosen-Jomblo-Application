import { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'io.ionic.starter',
  appName: 'JuliusAlfredo_36372_IF670_AL_UTS',
  webDir: 'build',
  bundledWebRuntime: false
};

export default config;
